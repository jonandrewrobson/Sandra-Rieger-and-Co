<?php

/**
 * @author: VLThemes
 * @version: 1.3.1
 */

?>

<div class="vlt-page-title">

	<div class="container">

		<div class="vlt-page-title__inner">

			<h1><?php the_title(); ?></h1>

			<?php echo leedo_get_breadcrumbs(); ?>

		</div>

	</div>

</div>
<!-- /.vlt-page-title -->