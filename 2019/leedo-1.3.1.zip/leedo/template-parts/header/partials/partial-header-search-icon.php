<?php

/**
 * @author: VLThemes
 * @version: 1.3.1
 */

if ( leedo_get_theme_mod( 'header_search_icon' ) == 'show' ) : ?>

	<a href="#" class="vlt-menu-search-icon">

		<i class="leedo-search"></i>

	</a>
	<!-- /.vlt-menu-search-icon -->

<?php endif; ?>