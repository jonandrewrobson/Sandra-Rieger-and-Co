<?php

/**
 * @author: VLThemes
 * @version: 1.3.1
 */

?>

<a href="#" id="vlt-menu-animated-toggle" class="vlt-menu-burger">

	<span class="line line-one"><span></span></span>

	<span class="line line-two"><span></span></span>

	<span class="line line-three"><span></span></span>

</a>
<!-- /.vlt-menu-burger -->