<?php

/**
 * @author: VLThemes
 * @version: 1.3.1
 */

?>

<a href="<?php the_permalink(); ?>" class="vlt-btn vlt-btn--third vlt-btn--effect"><span><?php esc_html_e( 'Read More', 'leedo' ); ?></span></a>
<!-- /.vlt-btn -->