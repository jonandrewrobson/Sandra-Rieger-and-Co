<?php

/**
 * @author: VLThemes
 * @version: 1.3.1
 */

?>

<a class="vlt-post-thumbnail__link" href="<?php the_permalink(); ?>"></a>
<!-- /.vlt-post-thumbnail__link -->