<?php
/**
 * Default pagination template.
 *
 * @var $args
 * @package visual-portfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<p class="vlt-alert">
	<?php echo esc_html( $args['notice'] ); ?>
</p>
